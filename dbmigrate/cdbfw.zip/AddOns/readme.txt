If you want to change the Numeric decimal point to a comma then run the file 'comma.reg'.
If you want to set a default decimal point (a dot) then run the file 'dot.reg'.

If you want to swap Delete and Ctrl-Delete then run 'SwapDels.reg'.
If you want to set default key functions then run 'DefaultDels.reg'.
 
If you want to limit a number of characters in the field then run 'UseMask.reg'.
If you do not want to limit a number of characters in the field then run 'DontUseMask.reg'.

If you want to swap F2 (Fields/Browse) and F4 (Edit mode) then run 'SwapF2F4.reg'.
If you want to set default key functions then run 'DefaultF2F4.reg'.
